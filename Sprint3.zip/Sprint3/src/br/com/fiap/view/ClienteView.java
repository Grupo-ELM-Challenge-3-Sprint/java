package br.com.fiap.view;

import br.com.fiap.controller.ClienteController;

import javax.swing.*;
import java.sql.SQLException;

public class ClienteView {
    public static void main(String[] args) {
        String idCliente, cpf, nome, senha;
        String[] choice = {"Inserir", "Alterar", "Excluir", "Listar"};
        int opcao;
        ClienteController clienteController = new ClienteController();
        do {
            try {

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Erro: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }
        } while (JOptionPane.showConfirmDialog(null, "Deseja continuar?", "Continuar", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE) == 0);
        JOptionPane.showMessageDialog(null, "Fim do programa", "Fim", JOptionPane.INFORMATION_MESSAGE);
    }
}
